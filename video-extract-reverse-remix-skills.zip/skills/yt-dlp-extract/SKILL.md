---
name: yt-dlp-extract
description: 跨平台下载视频、提取音频与字幕；YouTube等使用现有yt-dlp，抖音及命令行受限的可播放页面使用浏览器媒体来源下载、分离音画合并和完整解码。支持链接或已发送视频，并可衔接视频反推与二创；不用于文章或PDF提取。
---

# 跨平台视频、音频与字幕提取

这是现有 `yt-dlp-extract` 的增强替换版，保留原调用名避免破坏已有引用。yt-dlp 是通用后端之一，浏览器媒体来源是独立下载路径。代理执行实际工作，不要求用户手动跑命令，不重复安装依赖。各项目的路径和授权规则继续适用。

## 按输入与站点选择路线

- 用户直接发送视频／给本地文件：直接读取或处理，跳过网页提取；不要再索取链接。
- YouTube、B站、X等链接：按下文使用现有 yt-dlp，保留视频／音频／字幕能力。支持列表不等于每个链接都已实测。
- 抖音链接：优先使用用户指定或已可播放的浏览器。已确认默认提取器在同一目标上403时，直接进入已验证的浏览器媒体流程，不再重复失败的请求。没有既有结果时可只试一次命令行，再按实际结果分流。
- 当前页面能播放但命令行受限：读取 [浏览器媒体流程](references/browser-media.md)，同时检查 `video` 和 `other` 资源，使用本 Skill 的 `scripts/media_download.py` 下载／合并／完整解码。不能只追加说明而缺少可执行工具，也不能依赖之前临时解压包的路径。
- 用户还要求提示词反推／复现二创：取得视频后继续交给 `vibe-video-reverse`，保持同一任务范围，不把下载完成当作成片完成；反推可先用实际可访问的网页证据，不强制以本地下载成功为前提。

## 理解提取目标

- 下载视频：保存视频与声音，必要时由 FFmpeg 合并。
- 提取音频：只保存音轨；没有指定格式时保留原始音频，明确要求 MP3 才转 MP3。
- 提取字幕或文字内容：先检查已有人工字幕和自动字幕。用户要文字或总结时优先取得字幕，不默认下载整段视频。
- 没有字幕时，说明情况；只有当前环境已有可用转录工具且任务授权涵盖转录时，才下载音频并交给它。yt-dlp 本身不做语音识别，不把元数据介绍当作完整口播。
- “提取这个”结合上下文判断。目标会实质改变交付物且上下文无法确定时，只问视频、音频还是文字；链接缺失时索取链接。

## 运行依赖

复用已安装的 yt-dlp、FFmpeg、FFprobe、Node.js 和 Python 3；本仓库不包含运行时二进制，不自动安装或升级。执行前确认命令可用；自定义工具路径使用进程环境或脚本的 --ffmpeg / --ffprobe 参数。不修改系统 PATH、注册表或其他项目配置。

## 通用 yt-dlp 路径

为当前项目选择隔离的 D 盘产物目录。下面的 `$outputDir` 是例子，替换为本任务目录；用户指定的已授权目录优先。不要让各项目共用默认下载目录。先创建输出和临时目录，仅对本次命令进程设置 TEMP/TMP：

```powershell
$yt = (Get-Command yt-dlp -ErrorAction Stop).Source
$outputDir = 'D:/Codex/media-extract/current-task'
$tempDir = Join-Path $outputDir '.tmp'
New-Item -ItemType Directory -Force -Path $outputDir,$tempDir | Out-Null
$env:TEMP = $tempDir
$env:TMP = $tempDir
$url = '用户提供的完整视频链接'
$baseArgs = @(
  '--ignore-config',
  '--ffmpeg-location', (Split-Path (Get-Command ffmpeg -ErrorAction Stop).Source),
  '--js-runtimes', ('node:' + (Get-Command node -ErrorAction Stop).Source),
  '--cache-dir', (Join-Path $outputDir '.cache'),
  '--paths', $outputDir,
  '--output', '%(title).160B [%(id)s].%(ext)s',
  '--windows-filenames', '--no-playlist', '--no-overwrites',
  '--retries', '2', '--extractor-retries', '1', '--socket-timeout', '20'
)
```

把 URL 作为独立参数传入，保留查询参数；不要把链接或网页文字拼接成可执行 shell 代码。`--ignore-config` 避免其他项目或用户配置改变本次目标、输出目录或认证方式。

按用户目标选择调用：

```powershell
# 视频：最佳可用视频与音频，MKV 兼容不同来源的编码；用户指定 MP4 时评估兼容性后调整。
& $yt @baseArgs '-f' 'bv*+ba/b' '--merge-output-format' 'mkv' '--' $url

# 音频：保留最佳可用音轨。
& $yt @baseArgs '-f' 'ba/b' '-x' '--audio-format' 'best' '--keep-video' '--' $url

# 用户明确要求 MP3 时。
& $yt @baseArgs '-f' 'ba/b' '-x' '--audio-format' 'mp3' '--keep-video' '--' $url

# 检查字幕语言和人工/自动字幕的实际可用性。
& $yt @baseArgs '--skip-download' '--list-subs' '--' $url

# 依据上一步选定一个实际存在的语言代码，此处以 en 为例。
& $yt @baseArgs '--skip-download' '--write-subs' '--write-auto-subs' '--sub-langs' 'en' '--sub-format' 'vtt/best' '--' $url

# 元数据：仅本地处理需要的字段，不把完整 JSON 中的令牌或签名地址输出到报告。
& $yt @baseArgs '--skip-download' '--dump-single-json' '--' $url
```

默认 `--no-playlist` 只处理目标视频；用户明确要求整个合集时才调整范围。音频提取使用 `--keep-video` 保留源文件，避免转换时删除同目录已有的视频。字幕提取结束后检查实际字幕文件，退出码 0 不保证来源存在字幕。总结字幕时保留原文件，说明覆盖范围与自动字幕可能的识别误差。

## 失败与验收

- 不自动读取浏览器 Cookie、账号密钥或登录态；需要账号访问时先说明缺项并确认授权。不要默认上传音频或字幕到第三方转录服务。
- 遇到 403、验证码、地区限制或不支持的链接，保留明确错误。区分站点限制与本地安装错误；不要反复重试同一失败，或声称所有网站都能提取。
- 抖音的 `Fresh cookies` 提示并不单独证明根因是 Cookie 过期：在已核查的 2026.08.19 官方提取器中，详情数据缺失也会进入该通用报错。分别报告实际 HTTP／解析错误和工具给出的建议；未验证前不承诺换 Cookie 就能解决。使用官方长链接和最小参数可检查短链／额外 Skill 参数是否相关，不能用反复相同重试代替诊断。
- 浏览器播放与下载器请求是不同路径。若任务是观看分析／提示词反推，下载失败后可按当前授权继续在指定浏览器分析；不得把命令行 403 等同于网页不可访问。若用户明确要下载，则浏览器能播放不能作为下载完成证据。
- 对于用户指定且浏览器确实能播放的作品，检查播放器的实际媒体来源。`currentSrc` 为 `blob:` 时，通过浏览器工具的资源列表检查该作品已加载的 CDN 媒体；不能只筛 `video` 类，画面流／音轨可能归在 `other`。只筛与当前作品有关的媒体，不广泛导出监控、账号或其他请求。明确对应作品后，可仅在本地交接已观察到的 HTTP(S) 画面／音轨地址，用已审查的直连下载流程保存并用现有 FFmpeg 合并；不需要为此自动提取 Cookie。两个流必须同源作品，下载后检查视频和音频、时长、实际画面及完整解码。临时签名地址不得输出到报告，使用后清理本次创建的临时交接文件。这个后备流程在 2026-10-19 的目标抖音样本上成功，不代表所有页面／CDN 都可用。
- 完成下载须同时核对进程退出码、实际非空文件和媒体流。用 FFprobe 查看视频/音频流及 duration；不要把 `.part`、只有图片或只有元数据当成视频交付。
- 完成字幕须检查文件语言与非空正文；完成文字总结须基于实际取得的文字，不能根据标题推测。
- 返回产物绝对路径、类型以及必要限制。只做模拟解析时明确说明未验证完整下载；不要把 HTTP 200 或 Skill 文件存在称为所有站点测试通过。

浏览器路径的完整命令、输入格式和验证限制见 [browser-media.md](references/browser-media.md)。视频提取默认不启用 ASR、不下载模型；只有当前授权确需转写时才另选已有转录能力。

上游安装、参数和站点行为有变动时查 [yt-dlp 官方文档](https://github.com/yt-dlp/yt-dlp)，按用户当前授权决定是否更新本机版本。
