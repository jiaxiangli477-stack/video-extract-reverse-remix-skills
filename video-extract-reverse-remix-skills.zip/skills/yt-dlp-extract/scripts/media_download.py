"""Download observed browser media and verify it using existing FFmpeg tools.

Adapted locally from the user-supplied douyin-transcribe-windows package
(archive SHA256 812b934769a21fed5a560c32ad94a1e7d8b02d322c00cfeb4b86aeca4eb5a226).
No browser-cookie access, dependency installation, ASR or model download.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request


def ffmpeg_path():
    return (os.environ.get('FFMPEG_PATH') or os.environ.get('IMAGEIO_FFMPEG_EXE') or shutil.which('ffmpeg')
            or 'ffmpeg')


def run(command):
    result = subprocess.run(command, capture_output=True, timeout=600)
    if result.returncode:
        # FFmpeg can echo signed URLs; never relay unfiltered stderr.
        raise RuntimeError('Media processing failed; check streams, format and tool availability.')
    return result.stdout


def fetch(url, destination, referer=None):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        raise ValueError('Expected an observed HTTP(S) media URL, not a blob or local path.')
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130.0.0.0 Safari/537.36'}
    if referer:
        headers['Referer'] = referer
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=90) as response:
        content_type = response.headers.get('Content-Type', '').lower()
        if 'text/html' in content_type or 'mpegurl' in content_type or 'dash+xml' in content_type:
            raise ValueError('Response is a page or playlist; use an appropriate stream downloader.')
        with open(destination, 'xb') as output:
            shutil.copyfileobj(response, output)
    if Path(destination).stat().st_size < 1024:
        raise ValueError('Empty or incomplete media response.')


def media_args(ffmpeg, video, audio, destination, audio_only=False, allow_silent=False):
    args = [ffmpeg, '-nostdin', '-hide_banner', '-v', 'error', '-n', '-i', str(video)]
    if audio:
        args += ['-i', str(audio)]
    if audio_only:
        args += ['-map', '1:a:0' if audio else '0:a:0', '-vn']
    elif audio:
        args += ['-map', '0:v:0', '-map', '1:a:0']
    else:
        args += ['-map', '0:v:0', '-map', '0:a:0?' if allow_silent else '0:a:0']
    args += ['-c', 'copy', '-movflags', '+faststart', str(destination)]
    return args


def verify(ffmpeg, ffprobe, file, audio_only=False, allow_silent=False):
    probe = json.loads(run([ffprobe, '-v', 'error', '-show_entries',
        'format=duration,size:stream=codec_type,codec_name,width,height,sample_rate,channels',
        '-of', 'json', str(file)]))
    streams = probe.get('streams', [])
    has_video = any(s.get('codec_type') == 'video' for s in streams)
    has_audio = any(s.get('codec_type') == 'audio' for s in streams)
    if audio_only and not has_audio:
        raise ValueError('Audio stream is missing.')
    if not audio_only and (not has_video or (not allow_silent and not has_audio)):
        raise ValueError('Required video/audio stream is missing; confirm silent source before --allow-silent.')
    duration = float(probe.get('format', {}).get('duration', 0))
    if duration <= 0:
        raise ValueError('Media has no positive duration.')
    args = [ffmpeg, '-nostdin', '-hide_banner', '-v', 'error', '-xerror', '-i', str(file)]
    if not audio_only:
        args += ['-map', '0:v:0']
    if has_audio:
        args += ['-map', '0:a:0']
    args += ['-f', 'null', '-']
    run(args)
    return {'duration': duration, 'streams': streams, 'verified_full_decode': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--media-file', type=Path, help='Local JSON with video_url and optional audio_url; audio-only also accepts audio_url alone')
    inputs.add_argument('--media', help='Observed HTTP(S) media file URL')
    inputs.add_argument('--input', type=Path, help='Existing local media file')
    parser.add_argument('--audio', help='Matching audio URL, only with --media')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--referer', help='Source page origin when required by its CDN')
    parser.add_argument('--audio-only', action='store_true', help='Save source audio losslessly as audio.m4a; no MP3 conversion')
    parser.add_argument('--allow-silent', action='store_true', help='Only after confirming the source is intentionally silent')
    parser.add_argument('--ffmpeg', default=ffmpeg_path())
    parser.add_argument('--ffprobe', default=os.environ.get('FFPROBE_PATH') or shutil.which('ffprobe') or 'ffprobe')
    args = parser.parse_args()
    if args.audio and not args.media:
        parser.error('--audio requires --media')
    if args.audio_only and args.allow_silent:
        parser.error('--audio-only cannot be combined with --allow-silent')
    out = args.out.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    final = out / ('audio.m4a' if args.audio_only else 'video.mp4')
    meta_path = out / 'meta.json'
    if final.exists() or meta_path.exists():
        raise FileExistsError('Final output or metadata already exists; choose a new output directory.')
    with tempfile.TemporaryDirectory(prefix='media-', dir=out) as temp:
        stage = Path(temp)
        audio = None
        if args.input:
            video = args.input.expanduser().resolve(strict=True)
            if not video.is_file():
                raise ValueError('Input must be a local file.')
        else:
            if args.media_file:
                spec = json.loads(args.media_file.read_text(encoding='utf-8-sig'))
                video_url, audio_url = spec.get('video_url'), spec.get('audio_url')
                if args.audio_only and audio_url:
                    video_url, audio_url = audio_url, None
            else:
                video_url, audio_url = args.media, args.audio
            if not isinstance(video_url, str) or not video_url:
                raise ValueError('A playable video_url or audio-only audio_url is required.')
            video = stage / 'video.bin'
            fetch(video_url, video, args.referer)
            if audio_url:
                audio = stage / 'audio.bin'
                fetch(audio_url, audio, args.referer)
        ready = stage / final.name
        run(media_args(args.ffmpeg, video, audio, ready, args.audio_only, args.allow_silent))
        details = verify(args.ffmpeg, args.ffprobe, ready, args.audio_only, args.allow_silent)
        metadata = {'mode': 'local' if args.input else 'browser-media', 'file': final.name,
                    'bytes': ready.stat().st_size, **details}
        # URLs are deliberately absent. Commit only after complete decode.
        stage_meta = stage / 'meta.json'
        stage_meta.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
        ready.replace(final)
        stage_meta.replace(meta_path)
    print(json.dumps({**metadata, 'status': 'complete', 'file': str(final)}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'FAILED ({type(exc).__name__}): media not committed; check source, streams and dependencies. '
              'Signed URLs and raw tracebacks are withheld.', file=sys.stderr)
        sys.exit(1)
