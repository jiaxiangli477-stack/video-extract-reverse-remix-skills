#!/usr/bin/env node
// Local media preparation only. No network, ASR, browser state or shell expansion.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';

function run(executable, args) {
  const r = spawnSync(executable, args, { encoding: 'utf8', windowsHide: true,
    timeout: 180000, maxBuffer: 8 * 1024 * 1024, shell: false });
  if (r.error || r.status !== 0) throw new Error(`${path.basename(executable)} failed: ${r.error?.message ?? r.stderr?.trim() ?? r.status}`);
  return r.stdout;
}

async function main() {
  const opts = {};
  const allowed = new Set(['input', 'out', 'count', 'times', 'ffmpeg', 'ffprobe']);
  for (let i = 2; i < process.argv.length; i++) {
    const arg = process.argv[i];
    if (arg === '--help') {
      console.log('node prepare-evidence.mjs --input LOCAL_VIDEO --out NEW_OR_EMPTY_DIR [--count 12 | --times 0,1,2] [--audio] [--ffmpeg PATH] [--ffprobe PATH]');
      return;
    }
    if (arg === '--audio') { opts.audio = true; continue; }
    const key = arg.slice(2);
    if (!arg.startsWith('--') || !allowed.has(key) || !process.argv[i + 1] || process.argv[i + 1].startsWith('--')) throw new Error(`Invalid argument: ${arg}`);
    if (key in opts) throw new Error(`Duplicate option: ${arg}`);
    opts[key] = process.argv[++i];
  }
  if (!opts.input || !opts.out) throw new Error('--input and --out are required');
  if (opts.times && opts.count) throw new Error('Choose --times or --count');
  const input = fs.realpathSync(path.resolve(opts.input));
  if (!fs.statSync(input).isFile()) throw new Error('Input must be a local file');
  const out = path.resolve(opts.out);
  if (fs.existsSync(out) && (!fs.statSync(out).isDirectory() || fs.readdirSync(out).length)) throw new Error('Output must be a new or empty directory; existing results are preserved');
  const ffmpeg = opts.ffmpeg ?? process.env.FFMPEG_PATH ?? 'ffmpeg';
  const ffprobe = opts.ffprobe ?? process.env.FFPROBE_PATH ?? 'ffprobe';
  const probe = JSON.parse(run(ffprobe, ['-v', 'error', '-show_entries',
    'format=duration,start_time:stream=index,codec_type,codec_name,width,height,avg_frame_rate,r_frame_rate,time_base,start_time,duration,sample_rate,channels:stream_disposition=attached_pic',
    '-of', 'json', input]));
  const video = probe.streams?.find(s => s.codec_type === 'video' && !s.disposition?.attached_pic);
  if (!video) throw new Error('No moving video stream');
  const duration = Number(video.duration ?? probe.format?.duration);
  if (!Number.isFinite(duration) || duration <= 0) throw new Error('Cannot determine positive video duration');
  const fpsParts = (video.avg_frame_rate ?? '').split('/').map(Number);
  const fps = fpsParts.length === 2 && fpsParts[1] > 0 ? fpsParts[0] / fpsParts[1] : 0;
  const last = Math.max(0, duration - (fps > 0 ? 1 / fps : Math.min(0.1, duration / 2)));
  let times;
  if (opts.times) {
    const parts = opts.times.split(',');
    if (parts.some(v => !v.trim())) throw new Error('Empty timestamp');
    times = [...new Set(parts.map(Number))].sort((a, b) => a - b);
    if (!times.length || times.length > 120 || times.some(t => !Number.isFinite(t) || t < 0 || t >= duration)) throw new Error('Supply 1–120 timestamps in [0, duration)');
  } else {
    const count = Number(opts.count ?? 12);
    if (!Number.isInteger(count) || count < 2 || count > 120) throw new Error('--count must be an integer from 2 to 120');
    times = Array.from({ length: count }, (_, i) => last * i / (count - 1));
  }
  // Hash as a stream, so large reference videos do not need to fit in memory.
  const hash = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(input)) hash.update(chunk);
  fs.mkdirSync(out, { recursive: true });
  const manifest = { status: 'in_progress', input, sha256: hash.digest('hex'),
    duration, video, audio_streams: probe.streams.filter(s => s.codec_type === 'audio'),
    sampling: opts.times ? 'requested_timestamps' : 'uniform_overview_only',
    timestamp_note: 'Requested source-relative seconds, quantized to available decoded frames; not exact PTS or shot boundaries.',
    frames: [], audio: null, warnings: [] };
  const save = () => fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  save();
  try {
    for (const [i, t] of times.entries()) {
      const file = path.join(out, `frame-${String(i).padStart(3, '0')}-${t.toFixed(4)}s.png`);
      run(ffmpeg, ['-nostdin', '-v', 'error', '-n', '-ss', String(t), '-i', input,
        '-map', `0:${video.index}`, '-frames:v', '1', '-update', '1', file]);
      if (!fs.existsSync(file) || fs.statSync(file).size === 0) throw new Error(`No frame decoded at ${t}s`);
      manifest.frames.push({ requested_time: t, path: file });
    }
    if (opts.audio && manifest.audio_streams.length) {
      const file = path.join(out, 'analysis-mono16k.wav');
      run(ffmpeg, ['-nostdin', '-v', 'error', '-n', '-i', input, '-map', `0:${manifest.audio_streams[0].index}`,
        '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', file]);
      if (!fs.existsSync(file) || fs.statSync(file).size <= 44) throw new Error('Empty extracted audio');
      manifest.audio = { path: file, purpose: 'analysis downmix, not original quality or transcription' };
    } else if (opts.audio) manifest.warnings.push('Source has no audio stream; no audio fabricated');
    manifest.status = 'complete';
    save();
    console.log(JSON.stringify({ status: manifest.status, manifest: path.join(out, 'manifest.json'), frames: manifest.frames.length, audio: manifest.audio, warnings: manifest.warnings }));
  } catch (e) {
    manifest.status = 'failed'; manifest.error = e.message; save(); throw e;
  }
}
main().catch(e => { console.error(e.message); process.exitCode = 1; });
