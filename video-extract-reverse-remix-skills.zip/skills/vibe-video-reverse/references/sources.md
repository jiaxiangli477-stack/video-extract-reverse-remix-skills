# 调研与复用边界

日期：2026-10-19。本轮检查公开文档，不等于全部工具本机已安装或实测。本 Skill 没有移植第三方 Skill 代码；复用已有下载器、媒体工具和制作能力，补充代码动画的反推契约。

| 方案 | 已核实范围 | 采用方式 |
|---|---|---|
| [yt-dlp](https://github.com/yt-dlp/yt-dlp) | 提取媒体；站点认证／限制可阻止下载。源码、二进制与打包依赖许可分别核实。 | 衔接现有 yt-dlp-extract，不另写下载器。 |
| [FFprobe](https://www.ffmpeg.org/ffprobe.html)／[FFmpeg](https://www.ffmpeg.org/ffmpeg.html) | 媒体检查、抽帧、音轨转换；二进制许可受构建选项影响。 | 已有安装，增加无 npm 依赖的薄调用脚本。 |
| [PySceneDetect](https://github.com/Breakthrough/PySceneDetect) | 镜头切换检测；[BSD-3-Clause](https://github.com/Breakthrough/PySceneDetect/blob/main/LICENSE)。 | 大量切镜时的候选，初版不增加 Python／OpenCV 依赖，不能替代连续动画拆段。 |
| [WhisperX](https://github.com/m-bain/whisperX) | 语音识别和词级对齐。 | 确有口播且无字幕时再评估模型、许可和资源；本次不安装。 |
| [imooooc/video-to-prompt](https://github.com/imooooc/video-to-prompt) | README 描述基于 Gemini 的视频转提示词应用；[MIT](https://github.com/imooooc/video-to-prompt/blob/main/LICENSE)。需 API 与媒体传输。 | 通用生成模型路线候选，本次不引入额外云端依赖。 |
| [LunarXuan/video-prompt-reverse](https://github.com/LunarXuan/video-prompt-reverse/blob/main/SKILL.md) | 文档涵盖逐镜头规格、证据及优化，主要面向生成视频模型。 | 仅比较思路，完整包／许可证／运行效果尚未审计，不直接安装移植。 |
| [luozhilzh/video-prompt-reverse](https://github.com/luozhilzh/video-prompt-reverse/blob/main/SKILL.md) | 文档强调运动和模型提示词，平台能力仍需官方核实。 | 仅对比，不继承效果承诺或固定风格。 |

维护状态、商用适用性和兼容性没有经过完整评测。未来确需第三方包时固定 commit，审查完整内容、依赖、许可与数据流，尤其检查自动上传／社区提交行为。不能把 README 的宣称写成实测结论。
